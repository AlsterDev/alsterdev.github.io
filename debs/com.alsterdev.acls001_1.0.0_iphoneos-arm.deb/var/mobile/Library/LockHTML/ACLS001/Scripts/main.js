var a = ['','one ','two ','three ','four ', 'five ','six ','seven ','eight ','nine ','ten ','eleven ','twelve ','thirteen ','fourteen ','fifteen ','sixteen ','seventeen ','eighteen ','nineteen '];
var b = ['', '', 'twenty','thirty','forty','fifty'];
var weekday = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

function inWords (num) {
	if (num == 00) {
    	return "zerozero";
    }
	if (num < 20) {
    	return a[num];
    }
    else {
    	var numText = num.toString();
    	var numText = numText.split("");

      	var firstNum = numText[0];
      	var secondNum = numText[1];
      	return b[firstNum] + a[secondNum];
    }
    
}

function startTime() {
	var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
  	var today = new Date();
  	//var today = new Date("July 02, 2019 23:37:01");
  	var h = today.getHours();
  	var m = today.getMinutes();
    var dateString = weekday[today.getDay()] + " " + months[today.getMonth()] + " " + ("0" + today.getDate()).slice(-2) + ", " + today.getFullYear();
  	document.getElementById('hourText').innerHTML = inWords(h).toLowerCase();
    document.getElementById('minuteText').innerHTML = inWords(m).toUpperCase();
    document.getElementById('dateText').innerHTML = dateString.toUpperCase();
  	var t = setTimeout(startTime, 500);
}