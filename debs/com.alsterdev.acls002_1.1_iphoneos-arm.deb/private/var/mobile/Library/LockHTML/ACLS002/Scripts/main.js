function mainUpdate(type) {
	if (type == "battery") {
		if (batteryCharging == true) {
			document.getElementById('batteryImage').src = "Resource/batteryCharging.png";
			document.getElementById("batteryPercent").className = "batteryPercentCharging";
		}
		else {
			document.getElementById('batteryImage').src = "Resource/battery.png";
			document.getElementById("batteryPercent").className = "batteryPercent";
		}
		document.getElementById('batteryPercent').innerHTML = batteryPercent;
	}
	else if (type == "statusbar") {
		var wifiIcon = document.getElementById("wifiImage");
		var signalType = document.getElementById("signalTypeText");
		
		if (wifiName == "NA") {
			wifiIcon.style.display = "none";
			signalType.style.display = "inline-block";
		}
		else {
			wifiIcon.style.display = "inline-block";
			signalType.style.display = "none";
		}
		
		var signalBarsImage = "Resource/signalBars" + signalBars + ".png";
		var wifiBarsImage = "Resource/wifiBars" + wifiBars + ".png";
		
		document.getElementById("signalTypeText").innerHTML = signalNetworkType;
		document.getElementById('wifiImage').src = wifiBarsImage;
		document.getElementById('signalImage').src = signalBarsImage;
    }
}
